-- Run in the website database through phpMyAdmin BEFORE uploading the controllers.
-- Keep this SQL file outside online htdocs.
CREATE TABLE IF NOT EXISTS `reservation_reference_sequences` (
    `id` INT UNSIGNED NOT NULL,
    `last_number` BIGINT UNSIGNED NOT NULL DEFAULT 0,
    PRIMARY KEY (`id`)
) ENGINE=InnoDB;

-- Existing reservations count toward submission order. Re-running preserves the counter.
INSERT IGNORE INTO `reservation_reference_sequences` (`id`, `last_number`)
SELECT 1, COUNT(*) FROM `reservations`;

SELECT `id`, `last_number` FROM `reservation_reference_sequences` WHERE `id` = 1;
