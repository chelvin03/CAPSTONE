function gymBookingCalendar() {
    return {
        bookingMonth: '', bookingDays: {}, bookingLoading: false, bookingError: '', bookingRequest: 0,
        bookingOpening: '', bookingClosing: '', bookingPeriod: '',
        bookingClockMonth: '', bookingClockTimer: null,
        get bookingYears() {
            const first = Number(this.minimumDate.slice(0, 4));
            const last = Number(this.maximumDate.slice(0, 4));
            return Array.from({length: last - first + 1}, (_, index) => first + index);
        },
        async bookingChooseMonth(year, month) {
            const key = `${year}-${String(month).padStart(2, '0')}`;
            this.bookingMonth = key < this.minimumDate.slice(0, 7) ? this.minimumDate.slice(0, 7)
                : key > this.maximumDate.slice(0, 7) ? this.maximumDate.slice(0, 7) : key;
            await this.loadBookingMonth();
        },
        get bookingAvailablePeriods() { return (this.bookingSelectedDay?.slots || []).filter(slot => slot.available); },
        get bookingTimeError() {
            if (!this.startTime || !this.endTime) return '';
            if (this.startTime < (this.bookingOpening || '07:00') || this.endTime > (this.bookingClosing || '24:00')) return 'Reservations must be within 7:00 AM to 12 midnight.';
            if (![this.startTime, this.endTime].every(time => /^(?:(?:[01][0-9]|2[0-3]):(?:00|30)|24:00)$/.test(time))) return 'Choose start and end times on the hour or half-hour. Reservations must be at least 1 hour.';
            if (this.endTime <= this.startTime) return 'End Time must be after Start Time.';
            const minutes = time => Number(time.slice(0, 2)) * 60 + Number(time.slice(3, 5));
            if (minutes(this.endTime) - minutes(this.startTime) < 60) return 'Reservations must be at least 1 hour.';
            if (this.hasSelectedConflict) return 'Selected time overlaps with an existing reservation. Please choose from the remaining available time.';
            return '';
        },
        bookingFullAvailable() {
            const periods = this.bookingAvailablePeriods;
            const period = periods.length === 1 ? periods[0] : periods.find(slot => slot.start_time === this.bookingPeriod);
            if (!period) { this.message = 'Choose an available period to reserve in full.'; return; }
            this.bookingSelectSlot(period);
        },
        get bookingMonthLabel() {
            if (!this.bookingMonth) return '';
            const [year, month] = this.bookingMonth.split('-').map(Number);
            return new Date(year, month - 1, 1).toLocaleDateString([], {month: 'long', year: 'numeric'});
        },
        get bookingCells() {
            if (!this.bookingMonth) return [];
            const [year, month] = this.bookingMonth.split('-').map(Number);
            const cells = Array(new Date(year, month - 1, 1).getDay()).fill(null);
            for (let day = 1; day <= new Date(year, month, 0).getDate(); day++) {
                const key = `${year}-${String(month).padStart(2, '0')}-${String(day).padStart(2, '0')}`;
                cells.push({number: day, date: key, ...this.bookingDays[key]});
            }
            return cells;
        },
        get bookingSelectedDay() { return this.bookingDays[this.date]; },
        get bookingCanSubmit() {
            const day = this.bookingSelectedDay;
            return Boolean(!this.bookingLoading && !this.bookingError && day?.selectable && day.status !== 'full'
                && this.startTime && this.endTime > this.startTime && this.startTime >= this.bookingOpening
                && this.endTime <= this.bookingClosing && !this.bookingTimeError && !this.hasSelectedConflict);
        },
        bookingTime(time) { return time?.startsWith('24:00') ? '12:00 midnight' : (time ? new Date(`2000-01-01T${time}`).toLocaleTimeString([], {hour: 'numeric', minute: '2-digit'}) : ''); },
        bookingCanMove(offset) {
            if (!this.bookingMonth) return false;
            const [year, month] = this.bookingMonth.split('-').map(Number);
            const target = new Date(year, month - 1 + offset, 1);
            const key = `${target.getFullYear()}-${String(target.getMonth() + 1).padStart(2, '0')}`;
            return key >= this.minimumDate.slice(0, 7) && key <= this.maximumDate.slice(0, 7);
        },
        async bookingMoveMonth(offset) {
            if (!this.bookingCanMove(offset)) return;
            const [year, month] = this.bookingMonth.split('-').map(Number);
            const target = new Date(year, month - 1 + offset, 1);
            this.bookingMonth = `${target.getFullYear()}-${String(target.getMonth() + 1).padStart(2, '0')}`;
            await this.loadBookingMonth();
        },
        async openBookingCalendar() {
            this.bookingMonth = (this.date || this.minimumDate).slice(0, 7);
            if (!this.bookingClockTimer) {
                this.bookingClockMonth = new Date().getFullYear() + '-' + String(new Date().getMonth() + 1).padStart(2, '0');
                this.bookingClockTimer = setInterval(() => {
                    const today = new Date();
                    const month = today.getFullYear() + '-' + String(today.getMonth() + 1).padStart(2, '0');
                    if (month !== this.bookingClockMonth) window.location.reload();
                }, 60000);
            }
            await this.loadBookingMonth();
        },
        async loadBookingMonth() {
            const request = ++this.bookingRequest;
            this.bookingLoading = true; this.bookingError = ''; this.bookingDays = {};
            try {
                if (!this.facility) throw new Error('The gymnasium is unavailable. Please contact the administrator.');
                const url = new URL(this.bookingAvailabilityUrl, window.location.origin);
                url.searchParams.set('facility_id', this.facility); url.searchParams.set('month', this.bookingMonth);
                const response = await fetch(url, {headers: {'Accept': 'application/json'}, cache: 'no-store'});
                if (!response.ok) {
                    const error = await response.json().catch(() => ({}));
                    throw new Error(response.status === 422 ? (error.errors?.facility_id?.[0] || error.message || 'Invalid calendar request.')
                        : 'Calendar availability could not be loaded. Please try again.');
                }
                const data = await response.json();
                if (!data.days || !data.opening_time || !data.closing_time) throw new Error('The online calendar files need updating. Please contact the administrator.');
                if (request !== this.bookingRequest) return;
                this.bookingDays = data.days; this.bookingOpening = data.opening_time; this.bookingClosing = data.closing_time;
                if (this.bookingSelectedDay) this.occupied = this.bookingSelectedDay.occupied;
            } catch (error) { if (request === this.bookingRequest) this.bookingError = error.message; }
            finally { if (request === this.bookingRequest) this.bookingLoading = false; }
        },
        bookingSelectDate(day) {
            if (this.bookingLoading || this.bookingError || !day.selectable || day.status === 'full') return;
            this.bookingPeriod = ''; this.date = day.date; this.occupied = day.occupied; this.startTime = ''; this.endTime = ''; this.message = '';
            this.updateBookingSummary();
        },
        bookingSelectSlot(slot) {
            if (!slot.available || this.bookingLoading || this.bookingError || !this.bookingSelectedDay?.selectable) return;
            this.bookingPeriod = slot.start_time; this.startTime = slot.start_time; this.endTime = slot.end_time; this.updateBookingSummary();
        },
        updateBookingSummary() {
            const values = {'Reservation Date': this.selectedDateLabel, 'Start Time': this.bookingTime(this.startTime), 'End Time': this.bookingTime(this.endTime)};
            this.summary = this.summary.map(item => Object.hasOwn(values, item.label) ? {...item, value: values[item.label]} : item);
        }
    };
}
